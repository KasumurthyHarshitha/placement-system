package com.placement.repository;

import com.placement.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    // ✅ Define both methods so your controller and service won't throw errors
    User findByEmail(String email);
    User findByEmailAndPassword(String email, String password);
}

