package com.placement.service;

public class ApplicationService {

}
