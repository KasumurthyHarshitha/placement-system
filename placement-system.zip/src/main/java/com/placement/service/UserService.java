package com.placement.service;

import com.placement.model.User;

public interface UserService {
    User register(User user);
    User login(String email, String password);
}
