package com.placement.model;

import jakarta.persistence.*;

@Entity
public class Application {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String applicantName;
    private String email;
    private String phone;
    private String company;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    public Application() {}

    public Application(String applicantName, String email, String phone, String company, User user) {
        this.applicantName = applicantName;
        this.email = email;
        this.phone = phone;
        this.company = company;
        this.user = user;
    }

    // Getters and setters
    public Long getId() { return id; }

    public String getApplicantName() { return applicantName; }
    public void setApplicantName(String applicantName) { this.applicantName = applicantName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getCompany() { return company; }
    public void setCompany(String company) { this.company = company; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
}
