package com.placement.controller;

import com.placement.model.Application;
import com.placement.model.User;
import com.placement.repository.ApplicationRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class ApplicationController {

    @Autowired
    private ApplicationRepository applicationRepository;

    @GetMapping("/apply")
    public String showApplyPage(@RequestParam(required = false) String company, Model model) {
        model.addAttribute("company", company);
        return "apply";
    }

    @PostMapping("/submitApplication")
    public String submitApplication(@ModelAttribute Application application,
                                    @RequestParam("company") String company,
                                    HttpSession session) {
        User loggedInUser = (User) session.getAttribute("user");

        if (loggedInUser != null) {
            application.setUser(loggedInUser);
            application.setEmail(loggedInUser.getEmail());
            application.setPhone(loggedInUser.getPhone());
            application.setApplicantName(loggedInUser.getName());
            application.setCompany(company);

            applicationRepository.save(application);
            return "thankyou";
        } else {
            return "redirect:/login";
        }
    }

    @GetMapping("/applications")
    public String viewApplications(Model model) {
        model.addAttribute("applications", applicationRepository.findAll());
        return "applications";
    }
}
