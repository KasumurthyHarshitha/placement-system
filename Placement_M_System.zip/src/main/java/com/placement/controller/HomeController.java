// HomeController.java
package com.placement.controller;

import com.placement.model.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/")
    public String home() {
        return "home";
    }



    @GetMapping("/signupp")
    public String signupPage() {
        return "signupp";
    }

    @GetMapping("/jobs")
    public String jobsPage() {
        return "jobs";
    }

    @GetMapping("/companies")
    public String companiesPage() {
        return "companies";
    }

    @GetMapping("/profile")
    public String showProfile(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";
        }
        model.addAttribute("user", user);
        return "profile";
    }

   /*
     @GetMapping("/apply")
     public String applyPage() {
        return "apply";
    }
    */
    

    @GetMapping("/thankyou")
    public String thankyouPage() {
        return "thankyou";
    }
}
