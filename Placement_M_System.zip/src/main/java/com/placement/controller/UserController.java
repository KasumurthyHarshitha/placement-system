package com.placement.controller;

import com.placement.model.User;
import com.placement.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/register")
    public String registerUser(@ModelAttribute User user, Model model) {
        userRepository.save(user);
        model.addAttribute("message", "Registration successful. Please login.");
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String showLoginForm() {
        return "login"; 
    }

    @PostMapping("/loginUser")
    public String loginUser(@RequestParam String email,
                            @RequestParam String password,
                            @RequestParam String role,
                            HttpSession session,
                            Model model) {
        User existingUser = userRepository.findByEmailAndPassword(email, password);

        if (existingUser != null && existingUser.getRole().equals(role)) {
            session.setAttribute("user", existingUser);
            if (role.equals("admin")) {
                return "redirect:/admin/dashboard";
            } else {
                return "redirect:/profile";
            }
        } else {
            model.addAttribute("error", "Invalid credentials or role");
            return "login";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    @GetMapping("/editProfile")
    public String editProfileForm(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user != null) {
            model.addAttribute("user", user);
            return "edit-profile";
        } else {
            return "redirect:/login";
        }
    }

    @PostMapping("/updateProfile")
    public String updateProfile(@ModelAttribute("user") User updatedUser, HttpSession session) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser != null) {
            currentUser.setPhone(updatedUser.getPhone());
            currentUser.setSkills(updatedUser.getSkills());
            currentUser.setEducation(updatedUser.getEducation());
            userRepository.save(currentUser);
            session.setAttribute("user", currentUser);
            return "redirect:/profile";
        }
        return "redirect:/login";
    }
}
